A Pen created at CodePen.io. You can find this one at https://codepen.io/kathykato/pen/jzOxgv.

 I became inspired by this Dribbble shot (https://dribbble.com/shots/4318035-Toggle) and wanted to recreate it with pure CSS!